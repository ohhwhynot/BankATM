
/**
 * @ClassName: Main
 * @Author: Xudong Gao
 * @Description: This is a main function for the program.
 * @Date: Dec 2021
 */
public class Main {
    public static void main(String[] args)  {
        ATMHome atmHome = new ATMHome();
        atmHome.setVisible(true);
    }
}